﻿// Пользователь вводит дату рождения, программа сообщает его знак зодиака.

int Day;
int Month;

// Ввод компонентов даты рождения, их перевод из строки в число:
Console.WriteLine("Введите день своего рождения:");
Day = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Введите месяц своего рождения:");
Month = Convert.ToInt32(Console.ReadLine());

// Определение знака зодиака по числу и месяцу рождения:

switch (Month)
{
    case 1:
        {
            if (Day >= 1 && Day <= 19)
            { Console.WriteLine("Ваш знак зодиака - Козерог."); }
            else if (Day >= 20 && Day <= 31)
            { Console.WriteLine("Ваш знак зодиака - Водолей."); }
            else
            { Console.WriteLine("Дата рождения введена неверно."); }
            break;
        }
    case 2:
        {
            if (Day >= 1 && Day <= 19)
            { Console.WriteLine("Ваш знак зодиака - Водолей."); }
            else if (Day >= 20 && Day <= 28)
            { Console.WriteLine("Ваш знак зодиака - Рыбы."); }
            else
            { Console.WriteLine("Дата рождения введена неверно."); }
            break;
        }
    case 3:
        {
            if (Day >= 21 && Day <= 31)
            { Console.WriteLine("Ваш знак зодиака - Овен."); }
            else if (Day >= 1 && Day <= 20)
            { Console.WriteLine("Ваш знак зодиака - Рыбы."); }
            else
            { Console.WriteLine("Дата рождения введена неверно."); }
            break;
        }
    case 4:
        {
            if (Day >= 1 && Day <= 20)
            { Console.WriteLine("Ваш знак зодиака - Овен."); }
            else if (Day >= 21 && Day <= 30)
            { Console.WriteLine("Ваш знак зодиака - Телец."); }
            else
            { Console.WriteLine("Дата рождения введена неверно."); }
            break;
        }
    case 5:
        {
            if (Day >= 1 && Day <= 20)
            { Console.WriteLine("Ваш знак зодиака - Телец."); }
            else if (Day >= 21 && Day <= 31)
            { Console.WriteLine("Ваш знак зодиака - Близнецы."); }
            else
            { Console.WriteLine("Дата рождения введена неверно."); }
            break;
        }
    case 6:
        {
            if (Day >= 1 && Day <= 20)
            { Console.WriteLine("Ваш знак зодиака - Близнецы."); }
            else if (Day >= 21 && Day <= 30)
            { Console.WriteLine("Ваш знак зодиака - Рак."); }
            else
            { Console.WriteLine("Дата рождения введена неверно."); }
            break;
        }
    case 7:
        {
            if (Day >= 1 && Day <= 22)
            { Console.WriteLine("Ваш знак зодиака - Рак."); }
            else if (Day >= 23 && Day <= 31)
            { Console.WriteLine("Ваш знак зодиака - Лев."); }
            else
            { Console.WriteLine("Дата рождения введена неверно."); }
            break;
        }
    case 8:
        {
            if (Day >= 1 && Day <= 22)
            { Console.WriteLine("Ваш знак зодиака - Лев."); }
            else if (Day >= 23 && Day <= 31)
            { Console.WriteLine("Ваш знак зодиака - Дева."); }
            else
            { Console.WriteLine("Дата рождения введена неверно."); }
            break;
        }
    case 9:
        {

            if (Day >= 1 && Day <= 22)
            { Console.WriteLine("Ваш знак зодиака - Дева."); }
            else if (Day >= 23 && Day <= 30)
            { Console.WriteLine("Ваш знак зодиака - Весы."); }
            else
            { Console.WriteLine("Дата рождения введена неверно."); }
            break;
        }
    case 10:
        {
            if (Day >= 1 && Day <= 22)
            { Console.WriteLine("Ваш знак зодиака - Весы."); }
            else if (Day >= 23 && Day <= 31)
            { Console.WriteLine("Ваш знак зодиака - Скорпион."); }
            else
            { Console.WriteLine("Дата рождения введена неверно."); }
            break;
        }
    case 11:
        {
            if (Day >= 1 && Day <= 22)
            { Console.WriteLine("Ваш знак зодиака - Скорпион."); }
            else if (Day >= 23 && Day <= 30)
            { Console.WriteLine("Ваш знак зодиака - Стрелец."); }
            else
            { Console.WriteLine("Дата рождения введена неверно."); }
            break;
        }
    case 12:
        {
            if (Day >= 1 && Day <= 21)
            { Console.WriteLine("Ваш знак зодиака - Стрелец."); }
            else if (Day >= 22 && Day <= 31)
            { Console.WriteLine("Ваш знак зодиака - Козерог."); }
            else
            { Console.WriteLine("Дата рождения введена неверно."); }
            break;
        }
}