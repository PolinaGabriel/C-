﻿// Составить программу нахождения цифрового корня натурального числа.
// Чтобы получить цифровой корень, нужно сложить все цифры числа, потом все цифры полученного числа и так далее, пока не получится однозначное число (это и есть цифровой корень).

// Ввод числа:

Console.WriteLine("Введите натуральное число: ");
string Number = Console.ReadLine();

// Нахождение цифрового корня:

while (Number.Length != 1)
{
    // Ввод дополнительных переменных:
    string x = Number;
    int sum = 0;

    // Нахождение суммы цифр:
    for (int i = 1; i <= Number.Length; i++)
    {
        int x0 = Convert.ToInt32(x.Substring(0, 1));
        sum = sum + x0;
        x = x.Substring(1, x.Length - 1);
    }
    Number = Convert.ToString(sum);
}
Console.WriteLine("Цифровой корень числа: " + Number);