﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Autos
{
	internal class Program
	{
		static void Main()
		{
			Avto A1 = new Avto();
			Avto A2 = new Avto();

			string next = "да";

			while (next != "нет")
			{
				Console.WriteLine("Выберите машину:");
				Console.WriteLine("1");
				Console.WriteLine("2");
				Console.WriteLine();
				string choice = Console.ReadLine();
				Console.WriteLine();
				Console.WriteLine();

				Console.WriteLine("Выберите действие с машиной:");
				Console.WriteLine("1 - ввод информации об авто");
				Console.WriteLine("2 - вывод информации об авто");
				Console.WriteLine("3 - заправка бензобака");
				Console.WriteLine("4 - поездка");
				Console.WriteLine("5 - расчёт количества возможных аварий");
				Console.WriteLine();
				choice += Console.ReadLine();
				Console.WriteLine();
				Console.WriteLine();

				switch (choice)
				{
					case "11":
						{
							Console.ForegroundColor = ConsoleColor.Blue;
							Console.Write("Введите номер авто: ");
							A1.nom = Console.ReadLine();
							Console.Write("Введите литраж бензобака: ");
							A1.bak = Convert.ToDouble(Console.ReadLine());
							Console.Write("Введите расход топлива на 100 км: ");
							A1.ras = Convert.ToDouble(Console.ReadLine());
							Console.Write("Введите пробег: ");
							A1.prob = Convert.ToDouble(Console.ReadLine());
							Console.WriteLine();
							A1.InfoIn(A1.nom, A1.bak, A1.ras, A1.prob);
							Console.WriteLine();
							Console.ResetColor();
							break;
						}

					case "12":
						{
							Console.ForegroundColor = ConsoleColor.Blue;
							A1.InfoOut();
							Console.ResetColor();
							break;
						}

					case "13":
						{
							Console.ForegroundColor = ConsoleColor.Blue;
							A1.Zapravka();
							Console.WriteLine();
							Console.ResetColor();
							break;
						}

					case "14":
						{
							Console.ForegroundColor = ConsoleColor.Blue;
							Console.WriteLine("Введите координаты начала пути:");
							Console.Write("Введите x1: ");
							A1.x1 = Convert.ToDouble(Console.ReadLine());
							Console.Write("Введите y1: ");
							A1.y1 = Convert.ToDouble(Console.ReadLine());
							Console.WriteLine("Введите координаты конца пути:");
							Console.Write("Введите x2: ");
							A1.x2 = Convert.ToDouble(Console.ReadLine());
							Console.Write("Введите y2: ");
							A1.y2 = Convert.ToDouble(Console.ReadLine());
							Console.WriteLine();
							A1.Move();
							Console.WriteLine();
							Console.ResetColor();
							break;
						}

					case "15":
						{
							Console.WriteLine("Количество возможных аварий с участием этих машин: " + A1.Accident(A2));
							Console.WriteLine();
							break;
						}

					case "21":
						{
							Console.ForegroundColor = ConsoleColor.Green;
							Console.Write("Введите номер авто: ");
							A2.nom = Console.ReadLine();
							Console.Write("Введите литраж бензобака: ");
							A2.bak = Convert.ToDouble(Console.ReadLine());
							Console.Write("Введите расход топлива на 100 км: ");
							A2.ras = Convert.ToDouble(Console.ReadLine());
							Console.Write("Введите пробег: ");
							A2.prob = Convert.ToDouble(Console.ReadLine());
							Console.WriteLine();
							A2.InfoIn(A2.nom, A2.bak, A2.ras, A2.prob);
							Console.WriteLine();
							Console.ResetColor();
							break;
						}

					case "22":
						{
							Console.ForegroundColor = ConsoleColor.Green;
							A2.InfoOut();
							Console.ResetColor();
							break;
						}

					case "23":
						{
							Console.ForegroundColor = ConsoleColor.Green;
							A2.Zapravka();
							Console.WriteLine();
							Console.ResetColor();
							break;
						}

					case "24":
						{
							Console.ForegroundColor = ConsoleColor.Green;
							Console.WriteLine("Введите координаты начала пути:");
							Console.Write("Введите x1: ");
							A2.x1 = Convert.ToDouble(Console.ReadLine());
							Console.Write("Введите y1: ");
							A2.y1 = Convert.ToDouble(Console.ReadLine());
							Console.WriteLine("Введите координаты конца пути:");
							Console.Write("Введите x2: ");
							A2.x2 = Convert.ToDouble(Console.ReadLine());
							Console.Write("Введите y2: ");
							A2.y2 = Convert.ToDouble(Console.ReadLine());
							Console.WriteLine();
							A2.Move();
							Console.WriteLine();
							Console.ResetColor();
							break;
						}

					case "25":
						{
							Console.WriteLine("Количество возможных аварий с участием этих машин: " + A1.Accident(A2));
							Console.WriteLine();
							break;
						}

				}

				Console.WriteLine("Хотите продолжить?");
				next = Console.ReadLine();
				Console.WriteLine();
				Console.WriteLine();
			}
		}
	}
}